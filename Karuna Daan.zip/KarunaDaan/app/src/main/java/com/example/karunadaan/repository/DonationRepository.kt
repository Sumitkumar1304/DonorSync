package com.example.karunadaan.repository

import com.example.karunadaan.dao.DonationDao
import com.example.karunadaan.entity.DonatedItem
import com.example.karunadaan.firebase.FirebaseHelper

class DonationRepository(
    private val donationDao: DonationDao,
    private val firebaseHelper: FirebaseHelper
) {
    suspend fun insertDonation(donatedItem: DonatedItem){
        donationDao.insertDonation(donatedItem)
    }

    suspend fun getUnSyncedDonation() : List<DonatedItem> {
        return donationDao.getUnsyncedDonations()
    }

    suspend fun markAsSynced(donationItemId: Int){
        donationDao.markAsSynced(donationItemId)
    }
    suspend fun syncWithFirebase(donatedItem: DonatedItem, onSucess: () -> Unit, onFailure: (Exception) -> Unit){
        markAsSynced(donatedItem.id)
        firebaseHelper.syncDonationToRealtimeDatabase(donatedItem, { onSucess()}, {exception -> onFailure(exception)  } )
    }
}