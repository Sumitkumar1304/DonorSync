package com.example.karunadaan

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.getValue
import android.Manifest.permission.ACCESS_COARSE_LOCATION
import android.app.Instrumentation.ActivityResult
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GravityCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.karunadaan.workManager.SyncWorker
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    lateinit var drawableLayout:DrawerLayout
    lateinit var navigationView:NavigationView
    lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var categoryRecycler:RecyclerView
    lateinit var bottomNavigation:BottomNavigationView
    lateinit var mDatabaseRef:DatabaseReference
    lateinit var mAuth:FirebaseAuth
    lateinit var userName:String
//    lateinit var welcomeMainMessage:TextView
    lateinit var itemListRecyclerView: RecyclerView
    var TAG="MainActivity"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }

        //-----------------------Hooks-----------------------------
        drawableLayout=findViewById(R.id.main)
        navigationView=findViewById(R.id.nav_view)
        toolbar=findViewById(R.id.toolbar)
        categoryRecycler=findViewById(R.id.recyclerViewCategories)
        bottomNavigation=findViewById(R.id.bottomNavigationView)
//        welcomeMainMessage=findViewById(R.id.welcomeMainMessage)
        itemListRecyclerView=findViewById(R.id.recyclerViewItemList)


        mAuth=FirebaseAuth.getInstance()
        mDatabaseRef=FirebaseDatabase.getInstance().getReference()
        statusOnline()

        //sync data

//        val workRequest = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
//            .setConstraints(
//                Constraints.Builder()
//                    .setRequiredNetworkType(NetworkType.CONNECTED)
//                    .build()
//            )
//            .build()
//        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
//            "SyncWorker",
//            ExistingPeriodicWorkPolicy.KEEP,
//            workRequest
//        )


        //var logout = navigationView.menu.findItem(R.id.nav_logout)

        navigationView.setNavigationItemSelectedListener(this)
        // fetching userName and updating the ui

        mDatabaseRef.child("users").child((mAuth.currentUser!!.uid).toString()).child("userName").get().addOnSuccessListener {
            Log.i("firebase first page", "Got value ${it.value}")
            userName=it.value.toString()
            if (userName != null) {
                var greetingText = "Hii, "+userName[0].uppercase() + userName.substring(1)
                //welcomeMainMessage.text = greetingText
                navigationView.findViewById<TextView>(R.id.headerName)?.text = greetingText.toString()
            }

        }.addOnFailureListener{
            Log.e("firebase", "Error getting data", it)
        }

        // setting up recycler view of banner

        //banner recycler view

        val dataset = arrayOf("January", "February", "March")
        val datasetBanner = arrayOf(R.drawable.bannerimage_1,R.drawable.bannerimage_2,R.drawable.bannerimage_3,R.drawable.bannerimage_4,
            R.drawable.bannerimage_5,R.drawable.bannerimage_6,R.drawable.bannerimage_7)
        val customAdapter = topBarAdapter(datasetBanner)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewBanner)
        var mLayout= LinearLayoutManager(this)
        recyclerView.layoutManager = mLayout
        mLayout.orientation=LinearLayoutManager.HORIZONTAL
        recyclerView.adapter = customAdapter

        // setting up recycler view of itemList

        var dataset2 = arrayOf("Clothes", "Food", "Stationary","Electronics","Money")
        var itemsDataset = arrayListOf<DonateEntiy>()
        var dataset3= arrayOf(R.drawable.cloths_icon,R.drawable.food2_icon,R.drawable.book_icon,R.drawable.electronics,R.drawable.crowdfunding_icon)

        var customItemListAdapter = ItemListAdapter(itemsDataset)
        var mLayout3 = LinearLayoutManager(this)
        itemListRecyclerView.layoutManager = mLayout3
        mLayout3.orientation = LinearLayoutManager.VERTICAL
        itemListRecyclerView.adapter = customItemListAdapter

        mDatabaseRef.child( dataset2[0].toString()).get().addOnSuccessListener {

            Log.d(TAG,it.toString()+" parent hii"+it.childrenCount)
            itemsDataset.clear()
            for(  child in it.children){
                Log.d(TAG,child.value.toString()+"hii")
                child.child("Donation").getValue<DonateEntiy>()?.let { it1 -> itemsDataset.add(it1) }
            }
            customItemListAdapter.notifyDataSetChanged()

        }.addOnFailureListener{
            Log.e("firebase", "Error getting data", it)
        }

        var customCategoryAdapter= categoryAdapter(dataset2,dataset3) {
            positon,dataset ->

                Log.d(TAG,""+positon+" hii")
                mDatabaseRef.child(dataset[positon].toString()).get().addOnSuccessListener {

                    Log.d(TAG,it.toString()+" parent hii"+it.childrenCount)
                    itemsDataset.clear()
                    for(  child in it.children){
                        Log.d(TAG,child.value.toString()+"hii")
                        child.child("Donation").getValue<DonateEntiy>()?.let { it1 -> itemsDataset.add(it1) }
                    }
                    customItemListAdapter.notifyDataSetChanged()

                }.addOnFailureListener{
                    Log.e("firebase", "Error getting data", it)
                }

        }
        // category recycler view

        var mLayout2= LinearLayoutManager(this)
        categoryRecycler.layoutManager=mLayout2
        mLayout2.orientation=LinearLayoutManager.HORIZONTAL
        categoryRecycler.adapter= customCategoryAdapter

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator( R.drawable.location33 )
        //Navigation drawer menu
        var toogle:ActionBarDrawerToggle = ActionBarDrawerToggle(this,drawableLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close)
        drawableLayout.addDrawerListener(toogle)
        toogle.syncState()

        bottomNavigation.setOnNavigationItemSelectedListener {
            onClick(it)
            return@setOnNavigationItemSelectedListener true
        }
    }

    private fun onCategoryItemClick(position: Int) {

    }

    private fun signOut(): Boolean {

        mAuth.signOut()
        var intent=Intent(this,FirstPage::class.java)
        finish()
        startActivity(intent)
        return true
    }

    override fun onResume() {
        super.onResume()
        bottomNavigation.menu.getItem(0).setChecked(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        statusOffline()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.right_menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    // function that works when bottom navigation is cliked
     private fun onClick(menu:MenuItem){
         var id=menu.itemId
         when(id){
             R.id.chat->{ startActivity(Intent(this,chatActivity::class.java))}
             R.id.donate->{
                 var intent = Intent(this,DonateActivity::class.java)
                 intent.putExtra("userName",userName)
                 startActivity(intent)
             }
             R.id.feed->{
                 var intent = Intent(this, FeedPageActivity::class.java)
                 startActivity(intent)
             }
         }
    }

    private fun statusOnline(){
        mDatabaseRef.child("onlineUser").child(mAuth.uid!!).child("status").setValue("online")
        Log.d("MainActivity","online updated")
    }

    private fun statusOffline(){
        mAuth.uid?.let { mDatabaseRef.child("onlineUser").child(it).removeValue() }
    }
    private fun requestLocationPermission(){
        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ){
            if(it){
                acessLocation()
            }
            else{
                Toast.makeText(this,"Location permission in required",Toast.LENGTH_SHORT).show()
            }
        }
        //requestPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    private fun acessLocation(){
        Toast.makeText(this,"Accessing location..... ",Toast.LENGTH_SHORT).show()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                // Handle Home action
            }
            R.id.nav_logout -> {
                // Handle Profile action
                signOut()
            }
        }

        // Close the drawer after selecting an item
        drawableLayout.closeDrawer(GravityCompat.START)
        return true
    }
}