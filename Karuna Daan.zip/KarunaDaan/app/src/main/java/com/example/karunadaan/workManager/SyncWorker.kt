package com.example.karunadaan.workManager

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.karunadaan.dao.DonationDao
import com.example.karunadaan.database.DonationDatabase
import com.example.karunadaan.firebase.FirebaseHelper
import com.example.karunadaan.repository.DonationRepository
import com.google.firebase.database.FirebaseDatabase

class SyncWorker(
    private val context: Context,
    workerParams: WorkerParameters
): CoroutineWorker(context, workerParams) {
    override suspend fun doWork(): Result {
        val database = DonationDatabase.getInstance(context)
        val donationDao = database.donationDao()
        val firebaseHelper = FirebaseHelper(FirebaseDatabase.getInstance())
        val repository = DonationRepository(donationDao, firebaseHelper)

        val unSyncedDonations = repository.getUnSyncedDonation()

        unSyncedDonations.forEach{donatedItem->
            repository.syncWithFirebase(donatedItem,{
            }, { exception ->  Result.retry()
            })
        }
        return Result.success()
    }
}