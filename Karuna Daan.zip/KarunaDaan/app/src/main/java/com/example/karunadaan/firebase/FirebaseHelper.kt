package com.example.karunadaan.firebase

import android.content.ContentValues.TAG
import android.util.Log
import androidx.core.net.toUri
import com.example.karunadaan.entity.DonatedItem
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.lang.Exception

class FirebaseHelper(private val realtimeDatabase: FirebaseDatabase) {
    private val TAG ="FirebaseHelper"

    fun syncDonationToRealtimeDatabase(
        donatedItem: DonatedItem,
        onSucess: ()-> Unit,
        onFailure: (Exception) -> Unit
    ){
        val donationMap = mapOf(
            "donorUID" to donatedItem.donorUid,
            "item" to donatedItem.item,
            "quantity" to donatedItem.quantity,
            "category" to donatedItem.donationCategory,
            "donationTime" to donatedItem.donationTime,
            "location" to donatedItem.location
        )
        realtimeDatabase.getReference().child("donations").child(donatedItem.id.toString())
            .setValue(donationMap).addOnSuccessListener {
                onSucess() }
            .addOnFailureListener{
                onFailure(it)
            }
    }
}