package com.example.karunadaan

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.database

class OneToOneChat : AppCompatActivity() {

    lateinit var userName:TextView
    lateinit var sendMesageButton:ImageView
    lateinit var database:FirebaseDatabase
    lateinit var myDatabaseRef:DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_one_to_one_chat)

        userName=findViewById(R.id.donarUserName)
        sendMesageButton=findViewById(R.id.sendMessageButton)

        database = Firebase.database
        myDatabaseRef = database.getReference("message")

        userName.text=intent.extras?.getString("userName")



    }
}