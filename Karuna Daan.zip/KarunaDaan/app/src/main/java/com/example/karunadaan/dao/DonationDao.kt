package com.example.karunadaan.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.karunadaan.entity.DonatedItem

@Dao
interface DonationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDonation(donatedItem: DonatedItem )

    @Query("SELECT * FROM donations WHERE isSynced = 0 ")
    suspend fun getUnsyncedDonations():List<DonatedItem>

    @Query("UPDATE donations SET isSynced = 1 WHERE id = :donationId")
    suspend fun markAsSynced(donationId: Int)
}