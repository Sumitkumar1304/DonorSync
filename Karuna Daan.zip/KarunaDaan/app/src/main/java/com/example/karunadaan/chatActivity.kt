package com.example.karunadaan

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.getValue

class chatActivity : AppCompatActivity() {

    lateinit var allChatRecyclerView:RecyclerView
    lateinit var mDatabaseReference:DatabaseReference
    lateinit var mAuth:FirebaseAuth
    val TAG="chatActivity"
    var listUid= arrayListOf("")
    var list = arrayListOf<FriendList>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_chat)
        mDatabaseReference=FirebaseDatabase.getInstance().getReference()
        mAuth=FirebaseAuth.getInstance()


        allChatRecyclerView=findViewById(R.id.allChatRecyclerView)

        var list2 =arrayListOf("Rd4g5Nx8Ydhlt6GtXzGJNKFD6Rd2","pp3gHxjt7AUZU5382fzu0nklc6Z2","PdnjvBpxvbbyRILXgTTSHZEgZ6p2")

        //Recycler View settings
        var mLayout=LinearLayoutManager(this)
        mLayout.orientation=LinearLayoutManager.VERTICAL
        var recyclerViewAdapter=AllChatAdapter( list)
        {   position -> onListItemClick(position) }
        allChatRecyclerView.layoutManager=mLayout
        allChatRecyclerView.adapter=(recyclerViewAdapter)
        Log.d(TAG,"chatActivity being executed")


        var friendList=FriendList("Rd4g5Nx8Ydhlt6GtXzGJNKFD6Rd2","anshu kumar")
        var friendList2=FriendList("pp3gHxjt7AUZU5382fzu0nklc6Z2","Abhishek Mishra ")
        val friendReference=mDatabaseReference.child("friendDb").child(mAuth.uid.toString())
        var x = arrayListOf(friendList)
        x.add(friendList2)
        friendReference.setValue(x)
        friendReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // Get Post object and use the values to update the UI
                val friendList = dataSnapshot.getValue<ArrayList<FriendList>>()
                if (friendList != null) {
                    for( i in friendList){
                        list.add(i)
                    }
                }
                recyclerViewAdapter.notifyDataSetChanged()
                Log.d(TAG,"list has been set")
            }
            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException())
            }
        })


//
//        friendReference.addValueEventListener(friendListener)
//
//        val userReference=mDatabaseReference.child("users").child(mAuth.uid.toString())
//        val userListener = object : ValueEventListener {
//            override fun onDataChange(dataSnapshot: DataSnapshot) {
//                // Get Post object and use the values to update the UI
//                val friendList = dataSnapshot.getValue<UserEntity>()
////                if (friendList != null) {
////                    list = friendList.userName.toString()
////                }
//            }
//            override fun onCancelled(databaseError: DatabaseError) {
//                // Getting Post failed, log a message
//                Log.w(TAG, "loadPost:onCancelled", databaseError.toException())
//            }
//        }
//        userReference.addValueEventListener(userListener)

        }
    private fun onListItemClick(position: Int) {
        var intent=Intent(this,ChatActivity2::class.java)
//        var name=mDatabaseReference.child()

        intent.putExtra("name",list[position].userName)
        intent.putExtra("uid",list[position].userId)
        startActivity(intent)
    }
}