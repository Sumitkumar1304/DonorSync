package com.example.karunadaan.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "donations")
data class DonatedItem (
    @PrimaryKey(autoGenerate = true) val id: Int =0,
    val donorUid: String,
    val item:String,
    val quantity:Int,
    val donationCategory: DonationCategory,
    val donationTime: Long = System.currentTimeMillis(),
    val location: String,
    val isSynced:Boolean = false
){
}
enum class DonationCategory(val description: String) {
    CLOTHES("Clothes and apparels"),
    FOOD("Non-perishable food items"),
    MONEY("Monetary donations"),
    BOOKS("Books and educational materials"),
    ELECTRONICS("Electronic gadgets or devices"),
    OTHER("Miscellaneous items")
}
