package com.example.karunadaan

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    lateinit var loginButton:Button
    lateinit var changeToSignUp:TextView
    lateinit var enterEmail:EditText
    lateinit var enterPassword:EditText
    lateinit var mAuth:FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        loginButton = findViewById(R.id.buttonLogin)
        changeToSignUp = findViewById(R.id.changeTosignUp)
        enterEmail = findViewById(R.id.enterEmailId)
        enterPassword = findViewById(R.id.enterPassword)
        mAuth = FirebaseAuth.getInstance()

        changeToSignUp.setOnClickListener {
            var intent = Intent(this,SignUpPage::class.java)
            startActivity(intent)
        }
        loginButton.setOnClickListener {
            var email = enterEmail.text.toString()
            var password =enterPassword.text.toString()
            if( email.equals("") ){
                Snackbar.make(it,"Please enter email id ",Snackbar.LENGTH_SHORT).show()
            } else if( password.equals("") ){
                Snackbar.make(it,"Please enter password ",Snackbar.LENGTH_SHORT).show()
            }
            else{
                login(email,password)
            }
        }
    }
    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(ContentValues.TAG, "signInWithEmail:success")

                    val intent = Intent(this,MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(ContentValues.TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(
                        baseContext,
                        "User does not exist",
                        Toast.LENGTH_SHORT,
                    ).show()
                }
            }

    }
}