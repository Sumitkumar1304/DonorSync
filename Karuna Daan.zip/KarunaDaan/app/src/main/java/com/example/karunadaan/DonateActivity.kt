package com.example.karunadaan

import android.Manifest
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.OnProgressListener
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.UUID


class DonateActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    lateinit var address:EditText
    lateinit var uploadButton:Button
    lateinit var itemName:EditText
    lateinit var itemDescription:EditText
    lateinit var image:ImageView
    lateinit var userNameTextView:TextView
    lateinit var selectQuantity:Spinner
    lateinit var mAuth:FirebaseAuth
    lateinit var mDatabaseReference: DatabaseReference
    lateinit var mFirestore:StorageReference
    var SELECT_PICTURE = 200
    private var category:String ?= null
    private var quantity:Int? =null
    var imageUri:Uri?=null
    var TAG="DonateActivity"
    private val CAMERA_PERMISSION_CODE = 1000
    private val READ_PERMISSION_CODE = 1001
    private var filePath:Uri?=null
    private lateinit var dounloadUri:Uri
    private lateinit var userName:String


    val itemsCategory = arrayOf("Select category",
        "Clothes", "Stationary",
        "Food", "Electronics","Money"
    )
    val itemsQuantity = arrayOf("Number of items","1","2","3","4","5+")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_donate)
        userName = intent.extras?.getString("userName").toString()

        address=findViewById(R.id.enterLocation)
        image=findViewById(R.id.previewImageOfItem)
        selectQuantity=findViewById(R.id.selectQuantity)
        uploadButton=findViewById(R.id.uploadDonation)
        itemName=findViewById(R.id.enterItemName)
        itemDescription=findViewById(R.id.itemDescription)
        userNameTextView=findViewById(R.id.donarUserName)
        mAuth=FirebaseAuth.getInstance()
        mDatabaseReference=FirebaseDatabase.getInstance().getReference()
        mFirestore=FirebaseStorage.getInstance().reference.child("images").child("donationImage")

        userNameTextView.text = userName

        val spino = findViewById<Spinner>(R.id.selectItemcategory)
        spino.setOnItemSelectedListener(this)
        selectQuantity.setOnItemSelectedListener(this)

        val ad: ArrayAdapter<*> = ArrayAdapter<Any?>(
            this,
            android.R.layout.simple_spinner_item,
            itemsCategory
        )
        val ad2 = ArrayAdapter<Any?>(
            this,
            android.R.layout.simple_spinner_item,
            itemsQuantity
        )
        ad.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        ad2.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spino.setAdapter(ad)
        selectQuantity.setAdapter(ad2)

        uploadButton.setOnClickListener {
            if(address.text.toString().equals("")){
                Snackbar.make(findViewById(R.id.donate),"Please enter address",Snackbar.LENGTH_SHORT).show()
            }
            else if(itemName.text.toString().equals("")){
                Snackbar.make(findViewById(R.id.donate),"Please enter item's name",Snackbar.LENGTH_SHORT).show()
            }
            else if(itemDescription.text.toString().length>10){
                Snackbar.make(findViewById(R.id.donate),"Decription should be longer",Snackbar.LENGTH_SHORT).show()
            }
            else if(quantity == null ){
                Snackbar.make(findViewById(R.id.donate),"Please select category",Snackbar.LENGTH_SHORT).show()
            }
            else if(category == null){
                Snackbar.make(findViewById(R.id.donate),"Please select number of item",Snackbar.LENGTH_SHORT).show()
            }
            else if(filePath==null) {
                Snackbar.make(findViewById(R.id.donate),"Please select Image",Snackbar.LENGTH_SHORT).show()
            }
            else{
                uploadImage(filePath!!)
            }
        }
        image.setOnClickListener{
            requestStoragePermission()
            imageChoose()
        }

    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val spin = parent as Spinner
        if(spin.id==R.id.selectItemcategory) {
            if (position != 0) { category = itemsCategory[position] }
            else category=null
            Toast.makeText(
                getApplicationContext(),
                itemsCategory[position],
                Toast.LENGTH_LONG
            )
                .show();
        }
        else if(spin.id == R.id.selectQuantity) {
            if (position != 0) quantity = itemsQuantity[position].toInt()
            else category=null
            Toast.makeText(
                getApplicationContext(),
                itemsCategory[position],
                Toast.LENGTH_LONG
            )
                .show();
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
    private fun imageChoose(){
        var intent = Intent()
        intent.setType("image/*")
        intent.setAction(Intent.ACTION_GET_CONTENT)

        startActivityForResult(Intent.createChooser(intent,"Select Image"),SELECT_PICTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode === SELECT_PICTURE &&
            resultCode === RESULT_OK &&
            data != null &&
            data.getData() != null) {

            // Get the Uri of data
            filePath = data.getData()!!
            try {

                // Setting image on image view using Bitmap
                val bitmap = MediaStore.Images.Media
                    .getBitmap(
                        contentResolver,
                        filePath
                    )
                image.setImageBitmap(bitmap)
            } catch (e: IOException) {
                // Log the exception
                e.printStackTrace()
            }
        }
    }
    private fun uploadImage(imageUri:Uri) {
        if (filePath != null) {
            Log.d(TAG,filePath.toString())

            // Code for showing progressDialog while uploading
            var progressDialog =  ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            // Defining the child of storageReference
            var ref = mFirestore
                .child(
                    "images/"
                            + UUID.randomUUID().toString());

            // adding listeners on upload
            // or failure of image
            ref.putFile(filePath!!)
                .addOnSuccessListener(
                     OnSuccessListener<UploadTask.TaskSnapshot>() {
                            // Image uploaded successfully
                            // Dismiss dialog

                         it.storage.downloadUrl.addOnSuccessListener {
                             Log.d(TAG,"started to update database")
                             val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
                             val currentDate = sdf.format(Date())
                             System.out.println(" C DATE is  "+currentDate)
                             if(quantity==null)quantity=1
                             var donateEntity=
                                 DonateEntiy(
                                     uid = mAuth.currentUser!!.uid.toString(),
                                     userName = userName,
                                     category = category!!,
                                     address = address.text.toString(),
                                     imageUri = it.toString() ,
                                     time=currentDate.toString(),
                                     itemDescription=itemDescription.text.toString(),
                                     itemName=itemName.text.toString(),
                                     quantity= quantity.toString()
                                 )
                             var hashMapDonateEntity= HashMap<String,DonateEntiy>()
                             hashMapDonateEntity.put("Donation",donateEntity)
                             mDatabaseReference.child(category.toString()).push()
                                    .setValue(hashMapDonateEntity).addOnSuccessListener {
                                     Log.d(TAG,"updated sucessfully+"+category)
                                     progressDialog.dismiss()
                                     address.text.clear()
                                     image.setImageResource(R.drawable.upload_to_cloud)
                                     selectQuantity.setSelection(0)
                                     itemName.text.clear()
                                     itemDescription.text.clear()
                                     Toast
                                         .makeText(this,
                                             "Donated, Thanks for your Donation",
                                             Toast.LENGTH_SHORT)
                                         .show();
                             }.addOnFailureListener{
                                 Log.d(TAG,"Failed to update")
                             }
                         }
                    })

                .addOnFailureListener( OnFailureListener() {
                        // Error, Image not uploaded
                        progressDialog.dismiss();
                        Toast
                            .makeText(this,
                                "Failed " + it.message,
                                Toast.LENGTH_SHORT)
                            .show();
                })
                .addOnProgressListener(
                     OnProgressListener<UploadTask.TaskSnapshot>() {

                        // Progress Listener for loading
                        // percentage on the dialog box
                            var progress: Double
                            = (100.0
                                * it.getBytesTransferred()
                                / it.getTotalByteCount());
                            progressDialog.setMessage(
                                "Uploaded "
                                        + progress.toInt() + "%");
                    });
        }
    }

    var launchSomeActivity = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode
            == RESULT_OK
        ) {
            val data = result.data
            // do your operation from here....
            if (data != null
                && data.data != null
            ) {
                val selectedImageUri = data.data
                var selectedImageBitmap: Bitmap?=null
                try {
                    selectedImageBitmap = MediaStore.Images.Media.getBitmap(
                        this.contentResolver,
                        selectedImageUri
                    )
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                image.setImageBitmap(
                    selectedImageBitmap
                )
            }
        }
    }
    private fun requestStoragePermission(): Boolean {
        var permissionGranted = false
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ) {
            val storagePermissionNotGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_DENIED
            if ( storagePermissionNotGranted ) {
                val permission = arrayOf( Manifest.permission.READ_EXTERNAL_STORAGE )
                requestPermissions( permission, READ_PERMISSION_CODE )
            } else {
                permissionGranted = true
            }
        } else {
            permissionGranted = true
        }
        return permissionGranted
    }
}

