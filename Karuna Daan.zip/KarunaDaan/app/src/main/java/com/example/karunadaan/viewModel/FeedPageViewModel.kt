package com.example.karunadaan.viewModel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.karunadaan.entity.DonatedItem
import com.example.karunadaan.repository.DonationRepository
import kotlinx.coroutines.launch

class FeedPageViewModel(private val repository: DonationRepository) : ViewModel() {

        fun addDonation(donation: DonatedItem) {
            viewModelScope.launch {
                repository.insertDonation(donation)
            }
        }
}