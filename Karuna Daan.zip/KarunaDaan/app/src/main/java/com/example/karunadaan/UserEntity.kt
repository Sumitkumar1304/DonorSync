package com.example.karunadaan

class UserEntity {
    var userName:String? = null
    var email: String? = null
    var mobile_no: String?=null
    var uid: String? = null
    var location:String?=null
    constructor(){}
    constructor(name: String?, email: String?, uid: String?,mobile_no: String?){
        this.userName = name
        this.email = email
        this.uid = uid
        this.mobile_no=mobile_no
    }
}