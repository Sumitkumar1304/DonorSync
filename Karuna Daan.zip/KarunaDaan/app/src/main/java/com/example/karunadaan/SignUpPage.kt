package com.example.karunadaan

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class SignUpPage : AppCompatActivity() {

    lateinit var signUpOptionButton: Button
    lateinit var signInOptionButton: Button
    lateinit var enteredUserName: EditText
    lateinit var enteredPassword: EditText
    lateinit var reEnteredpassword: EditText
    lateinit var enteredmobileNumber: EditText
    lateinit var enteredOtp: EditText
    lateinit var enterEmail:EditText
    lateinit var rememberMe: RadioButton
    lateinit var signInSignUpButton: Button
    private var storedVerificationId: String? = null
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var googleSignInButton:ImageView
    private lateinit var resendToken:PhoneAuthProvider.ForceResendingToken
    private lateinit var changeToLoginActivity: TextView

    private lateinit var mCallBack: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    private val RC_SIGN_IN=1000
    private var SIGN_UP_CONSTANT=1


    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDatabaseRef: DatabaseReference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.content_sign_up_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        signUpOptionButton = findViewById(R.id.signUpOptionButton)
        signInOptionButton = findViewById(R.id.signInOptionButton)
        enteredUserName = findViewById(R.id.enteredUserName)
        enteredmobileNumber = findViewById(R.id.enteredMobileNumber)
        enteredPassword = findViewById(R.id.enteredPassword)
        reEnteredpassword = findViewById(R.id.reEnteredPassword)
        enteredOtp = findViewById(R.id.enteredOtp)
        rememberMe = findViewById(R.id.rememberMe)
        signInSignUpButton = findViewById(R.id.signUpSignInButton)
        googleSignInButton=findViewById(R.id.google_sign_in_button)
        mAuth = FirebaseAuth.getInstance()
        enterEmail=findViewById(R.id.enterEmail)
        changeToLoginActivity = findViewById(R.id.changeToLogin)

        mAuth = FirebaseAuth.getInstance()
        mDatabaseRef = FirebaseDatabase.getInstance().getReference()

        if(mAuth.currentUser != null){
            intent = Intent(this,MainActivity::class.java);
            startActivity(intent);
            finish()
        }
        changeToLoginActivity.setOnClickListener {
            var intent = Intent(this,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }


        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        signUpOptionButton.setOnClickListener {
            val params = signInSignUpButton.getLayoutParams() as ConstraintLayout.LayoutParams
            //change something in the params
            //change something in the params
            params.setMargins(0, 50, 0, 0)
            //set the button with the new params
            //set the button with the new params
            signInSignUpButton.setLayoutParams(params)
            signInSignUpButton.text = "Sign Up"
        }

//        signInOptionButton.setOnClickListener {
//            SIGN_UP_CONSTANT=0
//            signUpOptionButton.setTypeface(null, Typeface.NORMAL)
//            signInOptionButton.setTypeface(signInOptionButton.typeface, Typeface.BOLD)
//            enteredUserName.visibility = View.GONE
//            enteredmobileNumber.visibility = View.GONE
//            enteredOtp.visibility = View.GONE
//            reEnteredpassword.visibility = View.GONE
//            rememberMe.visibility = View.VISIBLE
//            val params = signInSignUpButton.getLayoutParams() as ConstraintLayout.LayoutParams
//            //change something in the params
//            //change something in the params
//            params.setMargins(0, 190, 0, 0)
//            //set the button with the new params
//            //set the button with the new params
//            signInSignUpButton.setLayoutParams(params)
//            signInSignUpButton.text = "Sign In"
//        }

        signInSignUpButton.setOnClickListener {
                val password = enteredPassword.text.toString()
                val rePassword = reEnteredpassword.text.toString()
                val mobileNumber = enteredmobileNumber.text.toString()
                var name = enteredUserName.text.toString()
                val email = enterEmail.text.toString()
                if (mobileNumber.equals("")) {
                    Toast.makeText(this, "please enter Mobile number", Toast.LENGTH_SHORT).show()
                } else if (!password.equals(rePassword) || password.equals("")) {
                    Log.d("LoginPage", password + " " + rePassword)
                    Toast.makeText(this, "please enter same password", Toast.LENGTH_SHORT).show()
                } else if (password.length < 6) {
                    Snackbar.make(
                        findViewById(R.id.login),
                        "Enter password of length atleast 6",
                        Snackbar.LENGTH_SHORT
                    ).show()
                } else {
                    val phone = "+91" + mobileNumber
                    signUp(name, email, password, mobileNumber)
                }
        }
        googleSignInButton.setOnClickListener {
            signIn()
        }
    }

    override fun onStart() {
        super.onStart()
        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if(account!=null){
            startActivity(Intent(this,MainActivity::class.java))
            finish()
        }
        //updateUI(account)
    }
    private fun signIn() {
        val signInIntent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }
    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }
    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)

            // Signed in successfully, show authenticated UI.
            //updateUI(account)
            startActivity(Intent(this,MainActivity::class.java))
            finish()
            Log.d("Login Page","Done signIn")
        } catch (e: ApiException) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.statusCode)
            //updateUI(null)
        }
    }
    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "signInWithEmail:success")

                    val intent = Intent(this,MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(
                        baseContext,
                        "User does not exist",
                        Toast.LENGTH_SHORT,
                    ).show()
                }
            }

    }
    private fun signUp(name: String, email: String, password: String,mobile_no: String) {
        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "createUserWithEmail:success")
                    // code to add user to database
                    addUserToDatabase(name,email, mAuth.uid!!, mobile_no)
                    val intent = Intent(this, MainActivity::class.java)
                    finish()
                    startActivity(intent)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "createUserWithEmail:failure", task.exception)
                    Toast.makeText(
                        baseContext,
                        "Authentication failed.",
                        Toast.LENGTH_SHORT,
                    ).show()
                }
            }

    }
    private fun addUserToDatabase(name: String, email: String, uid: String, mobile_no: String) {
        mDatabaseRef.child("users").child(uid).setValue(UserEntity(name,email,uid,mobile_no))
    }



}