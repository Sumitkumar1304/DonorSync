package com.example.karunadaan.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.karunadaan.dao.DonationDao
import com.example.karunadaan.entity.DonatedItem

@Database(entities = [DonatedItem::class], version = 1)
abstract class DonationDatabase:RoomDatabase() {
    abstract fun donationDao(): DonationDao

    companion object{
        @Volatile private var INSTANCE: DonationDatabase? = null
        fun getInstance(context: Context): DonationDatabase{
            return INSTANCE ?:
                synchronized(this){
                    INSTANCE ?: Room.databaseBuilder(
                        context.applicationContext, DonationDatabase::class.java, "donation_db"
                    ).build().also {
                        INSTANCE = it
                    }
                }
        }
    }
}