package com.example.karunadaan.composeUi

import androidx.activity.ComponentActivity

class MainComponentActivity: ComponentActivity() {


}